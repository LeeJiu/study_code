#include "Character.h"


int main(void)
{
	Character ch;
	ch.Create();
	ch.ShowAllInfo();


	return 0;
}